<footer class="main-footer">
    <div class="pull-right hidden-xs">      
    </div>
    <!---<strong>All rights reserved © <?php echo date('Y');?>.</strong> -->
	<strong>Copyright © <?php echo date('Y');?>- All rights reserved -Powered by INUBAAN SOFTWARE.</strong>
  </footer>

</body>
</html>