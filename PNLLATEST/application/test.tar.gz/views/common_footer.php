<footer class="main-footer">
    <div class="pull-right hidden-xs">      
    </div>
    <!---<strong>All rights reserved © <?php echo date('Y');?>.</strong> -->
	<strong>Copyright © <?php echo date('Y');?>- All rights reserved -Powered by INUBAAN SOFTWARE.</strong>
  </footer>
<span id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=46KN2EItVypIJyhUGDsaJwRmSQOzYRpRNvYKDLEhKZ3JHWANX54QWR5rS9GG"></script></span>
</body>
</html>