
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
				<!--<div class="col-xs-12 col-sm-5 	col-md-5 col-lg-5">
					<div id="gtco-logo"><a href="#">COMPANY logo</a></div>
				</div>-->
				<div class="col-xs-12 col-sm-2 	col-md-2 col-lg-2">
					<div id="gtco-logo"><a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>images/logogg.png" height="50px;" ></a></div>
				</div>
				<div class=" col-sm-10	col-md-10	col-lg-10 text-right menu-1">
					<ul>
						<li><a href="<?php echo base_url();?>">Home</a></li>
                       <!-- <li><a href="#">Blog</a></li>-->
						<li><a href="<?php echo base_url();?>about">About</a></li>
						 <li ><a href="<?php echo base_url();?>subscription">Pricing</a></li>
						<li><a href="<?php echo base_url();?>contact">Contact</a></li>
						<li><a href="<?php echo base_url();?>index.php/login">Sign In</a></li>
						 <li class="active"><a href="<?php echo base_url();?>howitwork">How It's Work ?</a></li>  
						<!--<li><a href="<?php echo base_url();?>index.php/feedback">Feedback</a></li>--> 
					</ul>
				</div>
				
			</div>
			
		</div>
	</nav>

	
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading gtco-heading-sm">
					<h2>How It's Work ?</h2>
				</div>
			</div>
			<div class="row animate-box">
				<div class="col-md-6">
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse quo est quis mollitia ratione magni assumenda repellat atque modi temporibus tempore ex. Dolore facilis ex sunt ea praesentium expedita numquam?</p> 
					<p>Quos quia provident consequuntur culpa facere ratione maxime commodi voluptates id repellat velit eaque aspernatur expedita. Possimus itaque adipisci rem dolorem nesciunt perferendis quae amet deserunt eum labore quidem minima.</p>
				</div>
				<div class="col-md-6">
					
                    <center>
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/p9Fh4ItiyEg?rel=0&amp;autoplay=1" frameborder="0"></iframe>
                </div>
            </center>
                    
                    
                    
				</div>
			</div>
            <div class="clearfix"></div>
            
            <div class="row abt_title">
        <h2>AN OVERVIEW</h2>
         
        </div>
            <p class="abtext">
       Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.      
            </p>
            
            
            
         <div class="row abt_title">
        <h2>AN OVERVIEW</h2>
         
        </div>    
            
           <ul class="develop-framework">
            <li>Websites This essentially deals with designing and development of websites, backend integration, developments of apps along with the maintenance of the same on a regular basis.</li>
            <li>Software� This area engages with writing, creating and developing online applications, desktop applications, ERP, etc that are customized according to the specific requirements of the clients.</li>
            <li>Promotion� Following the development of the website, Farntechs also deals with extensive promotional activities such as Social Media Marketing, Link Buildup and SEO operations.</li>
            <li>Designing �� Apart from the aforementioned online and software oriented services, Farntechs also excels in the task of creative designing including Corporate Identities, Logo, Brochure, Newsletters and Publications.</li>
          </ul> 
            
            
                <div class="row abt_title">
        <h2>AN OVERVIEW</h2>
         
        </div>
            <p class="abtext">
       Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.      
            </p>
            
            
            
		</div>
	</div>


	

